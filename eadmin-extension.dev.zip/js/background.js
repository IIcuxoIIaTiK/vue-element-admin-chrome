var background =
webpackJsonp_name_([7],{

/***/ 277:
/***/ (function(module, exports) {

console.log('This is BACKGROUND page!');

/***/ })

},[277]);
//# sourceMappingURL=background.js.map